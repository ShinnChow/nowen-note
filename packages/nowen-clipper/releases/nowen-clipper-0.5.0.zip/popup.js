import "./chunks/modulepreload-polyfill-DaKOjhqt.js";
import { g as getConfig, i as isConfigured, f as getAccountState, n as normalizeBaseUrl, l as listWorkspaces, r as resetAccountState, h as listNotebooks, s as setAccountState, j as setConfig } from "./chunks/api-Ca4K00ry.js";
function messageOf(error) {
  if (error instanceof Error) return error.message;
  return String(error || "");
}
function describeRuntimeMessageError(error) {
  const message = messageOf(error);
  if (/extension context invalidated/i.test(message)) {
    return "剪藏插件刚刚更新或重新加载。请关闭弹窗、刷新当前网页后再试。";
  }
  if (/could not establish connection|receiving end does not exist|message port closed|no receiving end/i.test(message)) {
    return "剪藏插件后台未正常启动。请在扩展管理页重新加载 Nowen Note Web Clipper，刷新当前网页后重试。";
  }
  return message || "插件通信失败，请重新打开剪藏弹窗后重试。";
}
let config;
let accountState;
let workspaces = [];
let notebooks = [];
let activeTab;
async function init() {
  config = await getConfig();
  const notConfigured = byId("not-configured");
  const main = byId("main");
  byId("open-options").addEventListener("click", () => chrome.runtime.openOptionsPage());
  byId("open-options-footer").addEventListener("click", () => chrome.runtime.openOptionsPage());
  if (!isConfigured(config)) {
    notConfigured.classList.remove("hidden");
    main.classList.add("hidden");
    return;
  }
  notConfigured.classList.add("hidden");
  main.classList.remove("hidden");
  accountState = await getAccountState(config);
  byId("server-preview").textContent = shortUrl(config.serverUrl);
  byId("account-preview").textContent = config.displayName || config.username || "已登录";
  input("tags").value = config.defaultTags || "";
  select("image-mode").value = accountState.imageMode;
  select("output-format").value = accountState.outputFormat;
  checkbox("pin-note").checked = accountState.isPinned;
  select("clip-mode").value = accountState.clipMode;
  checkbox("ai-enhance").checked = config.aiEnhanceEnabled;
  select("ai-mode").value = config.aiEnhanceMode;
  document.querySelectorAll("#ai-details input[data-task]").forEach((element) => {
    const key = element.dataset.task;
    element.checked = !!config.aiEnhanceTasks[key];
  });
  [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const pageTitle = activeTab?.title || "当前页面";
  byId("page-title").textContent = pageTitle;
  byId("page-title").setAttribute("title", pageTitle);
  await loadLocations();
  bindEvents();
  updateModeUi();
}
async function loadLocations() {
  const workspaceSelect = select("workspace");
  workspaceSelect.disabled = true;
  select("notebook").disabled = true;
  setPermissionHint("正在加载可写位置...", "neutral");
  try {
    workspaces = await listWorkspaces(config);
  } catch (error) {
    workspaces = [];
    setPermissionHint(`工作区加载失败：${String(error?.message || error)}`, "error");
  }
  workspaceSelect.innerHTML = "";
  workspaceSelect.append(new Option("👤 个人空间", "personal"));
  for (const workspace of workspaces) {
    const writable = workspace.role !== "viewer";
    const option = new Option(
      `${workspace.icon || "🏢"} ${workspace.name}${writable ? "" : "（只读）"}`,
      workspace.id
    );
    option.disabled = !writable;
    workspaceSelect.append(option);
  }
  const rememberedWorkspace = accountState.workspaceId || "personal";
  const exists = rememberedWorkspace === "personal" || workspaces.some((workspace) => workspace.id === rememberedWorkspace);
  workspaceSelect.value = exists ? rememberedWorkspace : "personal";
  workspaceSelect.disabled = false;
  await loadNotebooksForWorkspace(workspaceSelect.value, accountState.notebookId);
}
async function loadNotebooksForWorkspace(workspaceValue, preferredNotebookId = "") {
  const notebookSelect = select("notebook");
  notebookSelect.disabled = true;
  notebookSelect.innerHTML = "";
  notebookSelect.append(new Option("正在加载笔记本...", ""));
  const workspaceId = workspaceValue === "personal" ? null : workspaceValue;
  try {
    notebooks = await listNotebooks(config, workspaceId);
    notebookSelect.innerHTML = "";
    notebookSelect.append(new Option(`自动使用/创建「${config.defaultNotebook || "Web 剪藏"}」`, ""));
    const labels = buildNotebookLabels(notebooks);
    for (const notebook of [...notebooks].sort((a, b) => labels.get(a.id).localeCompare(labels.get(b.id)))) {
      notebookSelect.append(new Option(labels.get(notebook.id) || notebook.name, notebook.id));
    }
    notebookSelect.value = preferredNotebookId && notebooks.some((notebook) => notebook.id === preferredNotebookId) ? preferredNotebookId : "";
    notebookSelect.disabled = false;
    updatePermissionState();
  } catch (error) {
    notebooks = [];
    notebookSelect.innerHTML = "";
    notebookSelect.append(new Option("无法加载笔记本", ""));
    setPermissionHint(`笔记本加载失败：${String(error?.message || error)}`, "error");
  }
}
function bindEvents() {
  select("clip-mode").addEventListener("change", async () => {
    await persistState({ clipMode: currentMode() });
    updateModeUi();
  });
  select("workspace").addEventListener("change", async () => {
    const workspaceId = select("workspace").value;
    await persistState({ workspaceId, notebookId: "", notebookLabel: "" });
    await loadNotebooksForWorkspace(workspaceId);
    updateModeUi();
  });
  select("notebook").addEventListener("change", async () => {
    const notebookId = select("notebook").value;
    const notebookLabel = select("notebook").selectedOptions[0]?.textContent || "";
    await persistState({ notebookId, notebookLabel });
  });
  select("image-mode").addEventListener("change", () => {
    void persistState({ imageMode: select("image-mode").value });
  });
  select("output-format").addEventListener("change", () => {
    void persistState({ outputFormat: select("output-format").value });
  });
  checkbox("pin-note").addEventListener("change", () => {
    void persistState({ isPinned: checkbox("pin-note").checked });
  });
  checkbox("ai-enhance").addEventListener("change", () => {
    if (checkbox("ai-enhance").checked) byId("ai-details").classList.remove("hidden");
  });
  byId("ai-toggle-details").addEventListener("click", () => byId("ai-details").classList.toggle("hidden"));
  byId("clip").addEventListener("click", () => void save());
  byId("reset-current-account").addEventListener("click", async () => {
    accountState = await resetAccountState(config);
    select("clip-mode").value = accountState.clipMode;
    select("image-mode").value = accountState.imageMode;
    select("output-format").value = accountState.outputFormat;
    checkbox("pin-note").checked = accountState.isPinned;
    select("workspace").value = "personal";
    await loadNotebooksForWorkspace("personal");
    updateModeUi();
    showResult({ ok: true, noteTitle: "已恢复当前账号的默认选择" }, true);
  });
}
async function save() {
  const button = byId("clip");
  clearResult();
  if (!canWriteSelectedWorkspace()) {
    showResult({ ok: false, error: "当前工作区为只读权限，请选择可写空间" });
    return;
  }
  const mode = currentMode();
  const workspaceValue = select("workspace").value;
  if ((mode === "screenshot" || mode === "fullScreenshot") && workspaceValue !== "personal") {
    showResult({ ok: false, error: "截图模式暂不支持保存到工作区，请选择个人空间或使用正文剪藏" });
    return;
  }
  const tags = parseTags(input("tags").value);
  const notebookId = select("notebook").value || void 0;
  const notebookName = notebookId ? notebooks.find((notebook) => notebook.id === notebookId)?.name : config.defaultNotebook || "Web 剪藏";
  await Promise.all([
    persistState({
      clipMode: mode,
      workspaceId: workspaceValue,
      notebookId: notebookId || "",
      notebookLabel: select("notebook").selectedOptions[0]?.textContent || "",
      imageMode: select("image-mode").value,
      outputFormat: select("output-format").value,
      isPinned: checkbox("pin-note").checked
    }),
    setConfig({
      aiEnhanceEnabled: checkbox("ai-enhance").checked,
      aiEnhanceMode: select("ai-mode").value,
      aiEnhanceTasks: collectAiTasks()
    }).catch(() => void 0)
  ]);
  if (mode === "screenshot" || mode === "fullScreenshot") {
    if (!activeTab?.id) {
      showResult({ ok: false, error: "未找到当前标签页" });
      return;
    }
    const legacy = {
      type: "CLIP_REQUEST",
      mode,
      tabId: activeTab.id,
      overrideNotebook: notebookName,
      overrideTags: tags.join(","),
      comment: textarea("comment").value.trim() || void 0
    };
    void chrome.runtime.sendMessage(legacy).catch(() => void 0);
    window.close();
    return;
  }
  const request = {
    type: "ENHANCED_CLIP_REQUEST",
    mode,
    tabId: activeTab?.id,
    targetWorkspaceId: workspaceValue === "personal" ? null : workspaceValue,
    targetNotebookId: notebookId,
    targetNotebookName: notebookName,
    tags,
    comment: textarea("comment").value.trim() || void 0,
    isPinned: checkbox("pin-note").checked,
    imageMode: select("image-mode").value,
    outputFormat: select("output-format").value,
    quickNote: mode === "quickNote" ? {
      title: input("quick-title").value.trim() || void 0,
      content: textarea("quick-content").value
    } : void 0,
    aiEnhance: mode !== "quickNote" && checkbox("ai-enhance").checked,
    aiTasks: collectAiTasks(),
    aiMode: select("ai-mode").value
  };
  button.disabled = true;
  byId("progress").classList.remove("hidden");
  byId("progress-text").textContent = "准备中...";
  const progressHandler = (message) => {
    if (message?.type === "CLIP_PROGRESS") byId("progress-text").textContent = message.message;
  };
  chrome.runtime.onMessage.addListener(progressHandler);
  try {
    const response = await chrome.runtime.sendMessage(request);
    showResult(response);
    if (response.ok && mode === "quickNote") {
      input("quick-title").value = "";
      textarea("quick-content").value = "";
    }
  } catch (error) {
    showResult({
      ok: false,
      error: describeRuntimeMessageError(error)
    });
  } finally {
    chrome.runtime.onMessage.removeListener(progressHandler);
    byId("progress").classList.add("hidden");
    button.disabled = false;
  }
}
function updateModeUi() {
  const mode = currentMode();
  const quick = mode === "quickNote";
  const screenshot = mode === "screenshot" || mode === "fullScreenshot";
  byId("quick-note-panel").classList.toggle("hidden", !quick);
  byId("page-title-row").classList.toggle("hidden", quick);
  byId("web-options-panel").classList.toggle("hidden", quick || screenshot);
  byId("image-option").classList.toggle("hidden", quick || screenshot || mode === "simplified");
  select("output-format").disabled = mode === "fullpage" || screenshot;
  if (mode === "fullpage") select("output-format").value = "html";
  byId("clip").textContent = quick ? "保存速记" : screenshot ? "开始截图" : "剪藏到 Nowen Note";
  updatePermissionState();
}
function updatePermissionState() {
  const writable = canWriteSelectedWorkspace();
  const badge = byId("permission-badge");
  badge.textContent = writable ? "可写" : "只读";
  badge.classList.toggle("readonly", !writable);
  const mode = currentMode();
  if (!writable) {
    setPermissionHint("当前账号在该工作区只有查看权限，无法创建笔记。", "error");
  } else if ((mode === "screenshot" || mode === "fullScreenshot") && select("workspace").value !== "personal") {
    setPermissionHint("截图模式暂只支持个人空间；正文、选区和速记支持工作区。", "warning");
  } else {
    setPermissionHint("保存前会由服务器再次校验笔记本写权限。", "success");
  }
  byId("clip").disabled = !writable;
}
function canWriteSelectedWorkspace() {
  const id = select("workspace").value;
  if (!id || id === "personal") return true;
  return workspaces.find((workspace) => workspace.id === id)?.role !== "viewer";
}
function buildNotebookLabels(items) {
  const byNotebookId = new Map(items.map((item) => [item.id, item]));
  const labels = /* @__PURE__ */ new Map();
  for (const item of items) {
    const path = [];
    const visited = /* @__PURE__ */ new Set();
    let current = item;
    while (current && !visited.has(current.id)) {
      visited.add(current.id);
      path.unshift(current.name);
      current = current.parentId ? byNotebookId.get(current.parentId) : void 0;
    }
    labels.set(item.id, path.join(" / "));
  }
  return labels;
}
function showResult(response, informational = false) {
  const result = byId("result");
  const message = byId("result-message");
  const link = byId("result-link");
  const warningList = byId("warning-list");
  const failures = byId("image-failures");
  const failureList = byId("image-failure-list");
  result.classList.remove("hidden", "ok", "err");
  result.classList.add(response.ok ? "ok" : "err");
  message.textContent = informational ? response.noteTitle || "已完成" : response.ok ? `✅ 已保存「${response.noteTitle || "无标题"}」${response.images?.ok ? `，本地化 ${response.images.ok} 张图片` : ""}` : `❌ ${response.error || "保存失败"}`;
  if (response.noteUrl) {
    link.href = response.noteUrl;
    link.classList.remove("hidden");
  } else {
    link.classList.add("hidden");
  }
  if (response.warnings?.length) {
    warningList.textContent = response.warnings.join("\n");
    warningList.classList.remove("hidden");
  } else {
    warningList.classList.add("hidden");
  }
  const imageFailures = response.images?.failures || [];
  failureList.innerHTML = "";
  for (const item of imageFailures) {
    const li = document.createElement("li");
    li.textContent = `${shortResource(item.url)} — ${item.error}`;
    li.title = item.url;
    failureList.append(li);
  }
  failures.classList.toggle("hidden", imageFailures.length === 0);
}
function clearResult() {
  byId("result").classList.add("hidden");
  byId("warning-list").classList.add("hidden");
  byId("image-failures").classList.add("hidden");
}
async function persistState(patch) {
  accountState = await setAccountState(config, patch);
}
function collectAiTasks() {
  const tasks = {};
  document.querySelectorAll("#ai-details input[data-task]").forEach((element) => {
    const key = element.dataset.task;
    tasks[key] = element.checked;
  });
  return tasks;
}
function parseTags(value) {
  return Array.from(new Set(value.split(/[，,]/).map((tag) => tag.trim()).filter(Boolean))).slice(0, 20);
}
function currentMode() {
  return select("clip-mode").value;
}
function setPermissionHint(message, tone) {
  const element = byId("permission-hint");
  element.textContent = message;
  element.dataset.tone = tone;
}
function shortUrl(value) {
  try {
    return new URL(normalizeBaseUrl(value)).host;
  } catch {
    return value;
  }
}
function shortResource(value) {
  try {
    const parsed = new URL(value);
    return `${parsed.host}${parsed.pathname}`.slice(0, 80);
  } catch {
    return value.slice(0, 80);
  }
}
function byId(id) {
  return document.getElementById(id);
}
function input(id) {
  return byId(id);
}
function textarea(id) {
  return byId(id);
}
function select(id) {
  return byId(id);
}
function checkbox(id) {
  return byId(id);
}
void init();
