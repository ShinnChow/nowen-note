const DEFAULTS = {
  serverUrl: "",
  username: "",
  userId: "",
  token: "",
  refreshToken: "",
  displayName: "",
  defaultNotebook: "Web 剪藏",
  defaultTags: "",
  imageMode: "inline",
  includeSource: true,
  outputFormat: "markdown",
  quickCapture: false,
  quickCaptureMode: "article",
  lazyLoadScroll: true,
  maxImageCount: 120,
  maxSingleImageBytes: 8 * 1024 * 1024,
  maxTotalImageBytes: 60 * 1024 * 1024,
  imageTimeoutMs: 1e4,
  aiEnhanceEnabled: false,
  aiEnhanceTasks: {
    summary: true,
    tags: true,
    outline: false,
    title: false,
    highlight: false,
    translation: false
  },
  aiEnhanceMode: "prepend",
  aiEnhanceLanguage: "zh-CN",
  aiCustomInstruction: "",
  aiMaxInputChars: 6e3,
  aiFailureStrategy: "fallback"
};
const DEFAULT_ACCOUNT_STATE = {
  clipMode: "article",
  workspaceId: "personal",
  notebookId: "",
  notebookLabel: "",
  imageMode: "inline",
  outputFormat: "markdown",
  isPinned: false
};
const CONFIG_KEY = "nowenClipperConfig";
const ACCOUNT_STATE_KEY = "nowenClipperAccountStateV1";
async function getConfig() {
  const store = chrome.storage.sync || chrome.storage.local;
  const data = await store.get(CONFIG_KEY);
  const raw = data[CONFIG_KEY] || {};
  const merged = { ...DEFAULTS, ...raw };
  if (raw.aiEnhanceTasks) {
    merged.aiEnhanceTasks = { ...DEFAULTS.aiEnhanceTasks, ...raw.aiEnhanceTasks };
  }
  return merged;
}
async function setConfig(patch) {
  const current = await getConfig();
  const merged = {
    ...current,
    ...patch,
    aiEnhanceTasks: patch.aiEnhanceTasks ? { ...current.aiEnhanceTasks, ...patch.aiEnhanceTasks } : current.aiEnhanceTasks
  };
  const store = chrome.storage.sync || chrome.storage.local;
  await store.set({ [CONFIG_KEY]: merged });
  return merged;
}
function isConfigured(cfg) {
  return !!cfg.serverUrl && !!cfg.token;
}
function normalizeBaseUrl(url) {
  return url.trim().replace(/\/+$/, "");
}
function getAccountScope(cfg) {
  const server = normalizeBaseUrl(cfg.serverUrl).toLowerCase();
  const identity = (cfg.userId || cfg.username || "anonymous").trim().toLowerCase();
  return `${encodeURIComponent(server)}::${encodeURIComponent(identity)}`;
}
function getLegacyUsernameScope(cfg) {
  const username = cfg.username.trim().toLowerCase();
  if (!username) return null;
  const server = normalizeBaseUrl(cfg.serverUrl).toLowerCase();
  return `${encodeURIComponent(server)}::${encodeURIComponent(username)}`;
}
function readScopedState(all, cfg) {
  const current = all[getAccountScope(cfg)];
  if (current) return current;
  if (!cfg.userId) return {};
  const legacyScope = getLegacyUsernameScope(cfg);
  return legacyScope ? all[legacyScope] || {} : {};
}
async function getAccountState(cfg) {
  const data = await chrome.storage.local.get(ACCOUNT_STATE_KEY);
  const all = data[ACCOUNT_STATE_KEY] || {};
  const raw = readScopedState(all, cfg);
  return {
    ...DEFAULT_ACCOUNT_STATE,
    imageMode: cfg.imageMode,
    outputFormat: cfg.outputFormat,
    ...raw
  };
}
async function setAccountState(cfg, patch) {
  const data = await chrome.storage.local.get(ACCOUNT_STATE_KEY);
  const all = data[ACCOUNT_STATE_KEY] || {};
  const scope = getAccountScope(cfg);
  const current = {
    ...DEFAULT_ACCOUNT_STATE,
    imageMode: cfg.imageMode,
    outputFormat: cfg.outputFormat,
    ...readScopedState(all, cfg)
  };
  const next = { ...current, ...patch };
  const nextAll = { ...all, [scope]: next };
  const legacyScope = cfg.userId ? getLegacyUsernameScope(cfg) : null;
  if (legacyScope && legacyScope !== scope) delete nextAll[legacyScope];
  await chrome.storage.local.set({ [ACCOUNT_STATE_KEY]: nextAll });
  return next;
}
async function resetAccountState(cfg) {
  const data = await chrome.storage.local.get(ACCOUNT_STATE_KEY);
  const all = data[ACCOUNT_STATE_KEY] || {};
  delete all[getAccountScope(cfg)];
  const legacyScope = getLegacyUsernameScope(cfg);
  if (legacyScope) delete all[legacyScope];
  await chrome.storage.local.set({ [ACCOUNT_STATE_KEY]: all });
  return { ...DEFAULT_ACCOUNT_STATE, imageMode: cfg.imageMode, outputFormat: cfg.outputFormat };
}
class NowenApiError extends Error {
  constructor(status, code, message) {
    super(message);
    this.status = status;
    this.code = code;
    this.name = "NowenApiError";
  }
}
function authHeaders(cfg) {
  return {
    Authorization: `Bearer ${cfg.token}`,
    "Content-Type": "application/json"
  };
}
async function parseErr(res) {
  let code;
  let message = res.statusText;
  try {
    const data = await res.json();
    code = data.code;
    if (data.error) message = data.error;
  } catch {
    try {
      message = await res.text() || message;
    } catch {
    }
  }
  return new NowenApiError(res.status, code, `[${res.status}] ${message}`);
}
async function requestJson(cfg, path, init = {}) {
  const base = normalizeBaseUrl(cfg.serverUrl);
  const send = () => fetch(`${base}/api${path}`, {
    ...init,
    headers: {
      ...authHeaders(cfg),
      ...init.headers || {}
    }
  });
  let res = await send();
  if (res.status === 401 && cfg.refreshToken) {
    await refreshAccessToken(cfg);
    res = await send();
  }
  if (!res.ok) throw await parseErr(res);
  return await res.json();
}
const refreshInFlight = /* @__PURE__ */ new Map();
async function refreshAccessToken(cfg) {
  const base = normalizeBaseUrl(cfg.serverUrl);
  const key = `${base}
${cfg.refreshToken}`;
  let pending = refreshInFlight.get(key);
  if (!pending) {
    pending = (async () => {
      const res = await fetch(`${base}/api/auth/refresh`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ refreshToken: cfg.refreshToken })
      });
      if (!res.ok) {
        const error = await parseErr(res);
        if (res.status === 400 || res.status === 401 || res.status === 403) {
          error.terminal = true;
          await setConfig({ token: "", refreshToken: "" });
        }
        throw error;
      }
      const payload = await res.json();
      if (!payload.token) throw new Error("登录续期响应缺少访问令牌");
      cfg.token = payload.token;
      await setConfig({ token: payload.token });
      return payload.token;
    })().finally(() => refreshInFlight.delete(key));
    refreshInFlight.set(key, pending);
  }
  try {
    const token = await pending;
    cfg.token = token;
    return token;
  } catch (error) {
    if (error?.terminal) {
      cfg.token = "";
      cfg.refreshToken = "";
    }
    throw error;
  }
}
async function login(serverUrl, username, password) {
  const base = normalizeBaseUrl(serverUrl);
  const res = await fetch(`${base}/api/auth/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username, password })
  });
  if (!res.ok) throw await parseErr(res);
  return await res.json();
}
async function verify2FA(serverUrl, ticket, code) {
  const base = normalizeBaseUrl(serverUrl);
  const res = await fetch(`${base}/api/auth/2fa/verify`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ ticket, code })
  });
  if (!res.ok) throw await parseErr(res);
  return await res.json();
}
async function ping(cfg) {
  return requestJson(cfg, "/me");
}
async function listWorkspaces(cfg) {
  return requestJson(cfg, "/workspaces");
}
async function listNotebooks(cfg, workspaceId = null) {
  const scope = workspaceId ? encodeURIComponent(workspaceId) : "personal";
  return requestJson(cfg, `/notebooks?workspaceId=${scope}`);
}
async function importNote(cfg, payload) {
  const body = {
    notes: [
      {
        title: payload.title,
        content: payload.content,
        contentText: payload.contentText,
        contentFormat: payload.contentFormat,
        notebookName: payload.notebookName,
        notebookPath: payload.notebookPath,
        createdAt: payload.createdAt,
        updatedAt: payload.updatedAt
      }
    ]
  };
  if (payload.notebookId) body.notebookId = payload.notebookId;
  else if (payload.notebookName && !payload.notebookPath) body.notebookName = payload.notebookName;
  const scope = payload.workspaceId ? encodeURIComponent(payload.workspaceId) : "personal";
  return requestJson(cfg, `/export/import?workspaceId=${scope}`, {
    method: "POST",
    body: JSON.stringify(body)
  });
}
async function setNotePinned(cfg, noteId, pinned) {
  await requestJson(cfg, `/notes/${encodeURIComponent(noteId)}`, {
    method: "PUT",
    body: JSON.stringify({ isPinned: 1 })
  });
}
async function listTags(cfg, workspaceId) {
  const scope = workspaceId ? encodeURIComponent(workspaceId) : "personal";
  return requestJson(cfg, `/tags?workspaceId=${scope}&includeEmpty=true`);
}
async function createTag(cfg, name, workspaceId) {
  return requestJson(cfg, "/tags", {
    method: "POST",
    body: JSON.stringify({ name, workspaceId })
  });
}
async function attachTag(cfg, noteId, tagId) {
  await requestJson(cfg, `/tags/note/${encodeURIComponent(noteId)}/tag/${encodeURIComponent(tagId)}`, {
    method: "POST",
    body: "{}"
  });
}
async function ensureNoteTags(cfg, noteId, names, workspaceId) {
  const unique = Array.from(new Set(names.map((name) => name.trim()).filter(Boolean))).slice(0, 20);
  if (unique.length === 0) return [];
  const failures = [];
  let existing = await listTags(cfg, workspaceId).catch(() => []);
  for (const name of unique) {
    let tag = existing.find((item) => item.name.toLowerCase() === name.toLowerCase());
    if (!tag) {
      try {
        tag = await createTag(cfg, name, workspaceId);
        existing = [...existing, tag];
      } catch (error) {
        failures.push(`${name}：${String(error?.message || error)}`);
        continue;
      }
    }
    try {
      await attachTag(cfg, noteId, tag.id);
    } catch (error) {
      failures.push(`${name}：${String(error?.message || error)}`);
    }
  }
  return failures;
}
function buildNoteUrl(cfg, noteId) {
  return `${normalizeBaseUrl(cfg.serverUrl)}/?noteId=${encodeURIComponent(noteId)}`;
}
async function enhanceClip(cfg, payload) {
  return requestJson(cfg, "/ai/clip-enhance", {
    method: "POST",
    body: JSON.stringify(payload)
  });
}
export {
  NowenApiError as N,
  importNote as a,
  setNotePinned as b,
  ensureNoteTags as c,
  buildNoteUrl as d,
  enhanceClip as e,
  getAccountState as f,
  getConfig as g,
  listNotebooks as h,
  isConfigured as i,
  setConfig as j,
  login as k,
  listWorkspaces as l,
  normalizeBaseUrl as n,
  ping as p,
  resetAccountState as r,
  setAccountState as s,
  verify2FA as v
};
